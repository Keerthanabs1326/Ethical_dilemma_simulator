# DilemmaTree - Quick Start Guide 🚀

## 🎯 What is DilemmaTree?

DilemmaTree is an AI-powered platform that helps you visualize complex decisions. Simply describe your dilemma, and our AI (GPT-4o) generates an interactive tree showing all possible outcomes, their probabilities, and impacts.

---

## ⚡ Get Started in 3 Minutes

### Step 1: Access the Platform
Visit your deployed DilemmaTree URL (Vercel deployment)

### Step 2: Create an Account
1. Click **"Sign Up"** in the header
2. Enter your email, password, and name
3. Click **"Sign Up"**
4. You're automatically logged in!

### Step 3: Create Your First Dilemma
1. Click **"Create Dilemma"** in the header
2. Fill in the form:
   - **Title**: e.g., "Should we hire remote or in-office?"
   - **Description**: Provide context, constraints, stakeholders
   - **Category**: Choose from Ethical, Strategic, Personal, Business, or General
3. Click **"Continue to Review"**
4. Review your information
5. Click **"Generate Outcome Tree"** 
6. Wait 10-20 seconds while AI analyzes your dilemma
7. You'll be redirected to see your interactive outcome tree! 🌳

---

## 🌲 Understanding the Outcome Tree

### Tree Structure
- **Root Node** (Blue): Your original dilemma
- **Decision Branches** (Level 1): 3-4 main options you could take
- **Consequence Branches** (Level 2): 2-3 possible outcomes for each decision

### Node Information
Each node displays:
- **Content**: The decision or outcome
- **Probability**: Likelihood this happens (0-100%)
- **Impact**: How significant this is (1-10 scale)
- **Votes**: Community feedback (👍/👎)

### Navigation
- **Pan**: Click and drag to move around
- **Zoom**: Scroll mouse wheel or use controls (bottom-left)
- **Select**: Click any node to see full details
- **Minimap**: Use overview in bottom-right corner

---

## 💡 Example Dilemmas

### Business Decision
**Title**: "Should we pivot to a subscription model?"

**Description**: 
"Our SaaS startup currently uses one-time licensing. We're considering moving to monthly subscriptions to improve recurring revenue, but worried about customer backlash. Current ARR: $500K, 200 customers, 40% churn annually."

**AI Generated Tree** (example):
```
Root: Pricing Model Decision
├── Move to Subscription (prob: 60%, impact: 9/10)
│   ├── Customers convert smoothly (70%, 10/10)
│   └── High initial churn (30%, 6/10)
├── Keep One-Time License (prob: 80%, impact: 5/10)
│   ├── Stable but limited growth (85%, 5/10)
│   └── Lose competitive edge (15%, 7/10)
└── Hybrid Model (prob: 50%, impact: 7/10)
    ├── Best of both worlds (60%, 8/10)
    └── Complex to manage (40%, 6/10)
```

### Ethical Dilemma
**Title**: "Should we share user data with partners?"

**Description**:
"A major partner wants access to anonymized user behavior data to improve our shared product. This could generate $100K revenue and better features, but raises privacy concerns even with anonymization. 50K active users, GDPR compliant."

### Personal Decision
**Title**: "Should I accept the job offer in another city?"

**Description**:
"Received offer: 30% salary increase, dream role, but requires relocating 500 miles from family and friends. Current job is stable but limited growth. Partner is supportive but anxious about move."

---

## 🎨 Interacting with Dilemmas

### Voting
- Click 👍 (thumbs up) if you think a branch is likely/good
- Click 👎 (thumbs down) if you disagree
- Helps community understand popular perspectives

### Commenting
- Share your insights and experiences
- Ask questions about specific branches
- Discuss alternative perspectives
- Build on others' ideas

### Exploring
- Use **Explore** page to browse all dilemmas
- **Search** by keywords
- **Filter** by category
- **Sort** by recent, popular, or most viewed

---

## 📊 Your Dashboard

Access your dashboard to see:
- **Total Dilemmas**: How many you've created
- **Total Views**: Engagement on your dilemmas  
- **Reputation**: Community recognition
- **Your Dilemmas**: Quick access to manage your decisions

---

## 🎓 Best Practices

### Writing Good Dilemmas

#### ✅ DO:
- Provide specific context and numbers
- Mention stakeholders affected
- Include constraints and timeline
- Be honest about uncertainty
- Keep it focused on one decision

#### ❌ DON'T:
- Be too vague: "Should I change jobs?" 
- Ask multiple questions in one dilemma
- Leave out important context
- Use it for trivial decisions
- Include personal information

### Example - Bad vs Good

**❌ Bad**:
```
Title: Should I do it?
Description: I'm thinking about making a change.
```

**✅ Good**:
```
Title: Should I leave my corporate job to start a consultancy?
Description: I'm a senior product manager at a Fortune 500 (8 years experience, $150K salary). Considering starting a product strategy consultancy. Have 3 potential clients lined up ($80K first-year revenue estimate). Wife is supportive, mortgage is $2.5K/month, 6 months savings. Main concern is healthcare and stability for our 2 kids.
```

---

## 🔍 Understanding Probabilities & Impact

### Probability (0-100%)
- **80-100%**: Very likely to happen
- **60-79%**: Likely
- **40-59%**: Uncertain, could go either way  
- **20-39%**: Unlikely but possible
- **0-19%**: Very unlikely

### Impact (1-10 scale)
- **9-10**: Transformational, life/business changing
- **7-8**: Major impact, significant consequences
- **5-6**: Moderate impact, noticeable change
- **3-4**: Minor impact, small effects
- **1-2**: Minimal impact, barely noticeable

### Example Interpretation
**Branch**: "Raise $5M Series A"
- **Probability: 40%** = Challenging but achievable
- **Impact: 10/10** = Would completely transform the business

**Branch**: "Lose 2-3 customers"  
- **Probability: 65%** = Likely to happen
- **Impact: 4/10** = Manageable, not critical

---

## 🚀 Power User Tips

### 1. Compare Alternatives
Create separate dilemmas for:
- Same situation, different framings
- Different stakeholder perspectives
- Various time horizons

### 2. Update Over Time
- Check back after making your decision
- Compare AI predictions vs reality
- Learn from outcome analysis

### 3. Collaborate
- Share dilemma links with team/friends
- Gather votes and comments before deciding
- Use community wisdom

### 4. Export for Meetings
- Use share button to get link
- Present tree in stakeholder meetings
- Export option coming soon!

### 5. Build Reputation
- Create thoughtful dilemmas
- Provide helpful comments
- Engage with community
- Earn reputation points

---

## ❓ Troubleshooting

### Tree Not Showing?
1. Refresh the page (F5)
2. Check browser console for errors (F12)
3. Verify your dilemma was created successfully
4. Wait a few seconds - large trees take time to load

### AI Generation Failed?
1. Try again - occasional OpenAI timeouts
2. Check your description is clear
3. Make sure you're logged in
4. If persists, contact support

### Can't Vote/Comment?
- Ensure you're logged in
- Check network connection
- Refresh and try again

### Slow Loading?
- Normal for complex trees (15+ nodes)
- Try closing minimap if needed
- Clear browser cache

---

## 📱 Mobile Usage

DilemmaTree is fully responsive:
- Touch to pan the tree
- Pinch to zoom
- Tap nodes to select
- All features available on mobile

---

## 🎯 Next Steps

1. ✅ Created account
2. ✅ Made first dilemma  
3. ✅ Explored the tree
4. ⬜ Vote on community dilemmas
5. ⬜ Add insightful comments
6. ⬜ Create dilemma in different category
7. ⬜ Share with colleague/friend
8. ⬜ Check your dashboard

---

## 💬 Community Guidelines

- **Be respectful**: Constructive feedback only
- **Be helpful**: Share knowledge and experience  
- **Be honest**: Vote based on genuine opinion
- **Be specific**: Add value with details
- **Be open**: Consider different perspectives

---

## 🌟 Success Stories

### Real-World Applications
- **Startup pivots**: Validated direction changes
- **Hiring decisions**: Evaluated candidate trade-offs
- **Product launches**: Assessed market entry strategies
- **Career moves**: Compared job opportunities
- **Investment choices**: Analyzed risk/reward

---

## 📞 Getting Help

### In-App
- Visit **Help** page for documentation
- Check console logs (F12) for errors
- Review this guide

### Resources
- `README.md` - Complete documentation
- `FIXES_APPLIED.md` - Technical details
- GitHub issues - Report bugs

---

## 🎉 Welcome to DilemmaTree!

You're now ready to:
- ✅ Visualize complex decisions
- ✅ Explore AI-generated outcomes  
- ✅ Get community insights
- ✅ Make better choices

**Happy decision making! 🌳**

---

*Built with ❤️ using React, Supabase, and OpenAI GPT-4o*
