# DilemmaTree 🌳

A full-stack AI-powered decision visualization platform that maps ethical or strategic dilemmas into interactive consequence trees.

## Features

### Core Functionality
- **AI-Powered Outcome Generation**: Uses GPT-4o to automatically generate comprehensive decision trees with multiple branches, probabilities, and impact scores
- **Interactive Tree Visualization**: Built with React Flow for exploring decision paths and consequences
- **User Authentication**: Secure signup/login with Supabase Auth
- **Voting System**: Upvote/downvote dilemmas and individual branches
- **Real-time Comments**: Discuss dilemmas and specific decision branches
- **User Profiles**: Track reputation, created dilemmas, and contributions
- **Multi-Category Support**: Ethical, Strategic, Personal, Business, and General dilemmas

### Pages
- **Home**: Landing page with platform overview
- **Explore**: Browse and filter published dilemmas
- **Create**: Step-by-step wizard to create new dilemmas
- **Dashboard**: View your dilemmas and statistics
- **Dilemma Detail**: Explore outcome trees, vote, and comment
- **Profile**: User profiles with reputation and dilemma history
- **Help**: Platform documentation and guides

## Tech Stack

### Frontend
- **React** + **TypeScript** + **Vite**
- **Tailwind CSS** for styling
- **React Router** for navigation
- **React Flow** for tree visualization
- **Shadcn/UI** components
- **Lucide React** icons
- **Sonner** for toast notifications

### Backend
- **Supabase** for backend infrastructure:
  - Authentication (email/password)
  - PostgreSQL database with KV store
  - Edge Functions (Hono web server)
  - Storage for file uploads
- **OpenAI GPT-4o** for AI outcome generation

### Architecture
- Three-tier: Frontend → Server (Edge Functions) → Database
- RESTful API with 20+ endpoints
- Real-time data fetching
- Responsive design (mobile-first)

## Getting Started

### Prerequisites
- Node.js 18+
- Supabase account
- OpenAI API key (for AI generation)

### Environment Variables
The following environment variables are required (already configured in Supabase):
- `SUPABASE_URL` - Your Supabase project URL
- `SUPABASE_ANON_KEY` - Supabase anonymous key
- `SUPABASE_SERVICE_ROLE_KEY` - Supabase service role key
- `OPENAI_API_KEY` - OpenAI API key for GPT-4o

### Installation

1. **Clone or access the project**
   ```bash
   # The project is ready to deploy on Vercel
   ```

2. **Deploy to Vercel**
   - Connect your repository to Vercel
   - Vercel will automatically detect Vite configuration
   - No additional environment variables needed in Vercel (they're in Supabase)

3. **Access the Application**
   - Once deployed, visit your Vercel URL
   - Create an account to start using DilemmaTree

## Usage

### Creating a Dilemma

1. **Login/Signup**: Create an account or sign in
2. **Navigate to Create**: Click "Create Dilemma" from the header or dashboard
3. **Fill in Details**:
   - Title: A concise description of your dilemma
   - Description: Provide context, stakeholders, constraints
   - Category: Choose the appropriate category
4. **Generate Tree**: Click "Generate Outcome Tree"
   - AI will analyze your dilemma
   - Creates 1 root node + 3-4 main branches + 2-3 sub-branches each
   - Includes probability estimates (0-100) and impact scores (1-10)
5. **View Result**: Redirected to the dilemma detail page with interactive tree

### Exploring Dilemmas

1. **Browse**: Visit the Explore page
2. **Filter**: Search by keyword or filter by category
3. **Sort**: By recent, popular, or most viewed
4. **View Details**: Click any dilemma card to see the full outcome tree
5. **Interact**:
   - Vote on the dilemma or specific branches
   - Add comments and insights
   - Click nodes to see detailed information

### Outcome Tree Navigation

- **Pan**: Click and drag to move around
- **Zoom**: Use mouse wheel or controls
- **Select Node**: Click any node to see details
- **Vote**: Use thumbs up/down icons on nodes
- **Minimap**: Use the overview in bottom-right corner

## API Endpoints

### Authentication
- `POST /auth/signup` - Create new user account
- `GET /auth/me` - Get current user profile

### Dilemmas
- `POST /dilemmas` - Create new dilemma
- `POST /dilemmas/:id/generate-tree` - Generate AI outcome tree
- `GET /dilemmas` - Get all published dilemmas
- `GET /dilemmas/:id` - Get single dilemma
- `GET /dilemmas/:id/branches` - Get branches for a dilemma
- `GET /users/:userId/dilemmas` - Get user's dilemmas

### Voting
- `POST /vote` - Vote on dilemma or branch

### Comments
- `POST /comments` - Add comment
- `GET /dilemmas/:id/comments` - Get comments for dilemma

### Users
- `GET /users/:userId` - Get user profile
- `PUT /users/:userId` - Update user profile

## Database Schema

### KV Store Tables
- `user:{userId}` - User profiles
- `dilemma:{dilemmaId}` - Dilemma data
- `branch:{branchId}` - Tree branch nodes
- `comment:{commentId}` - Comments
- `vote:{userId}:{type}:{id}` - User votes

### Reference Keys
- `user:{userId}:dilemma:{dilemmaId}` - User's dilemmas
- `dilemma:{dilemmaId}:branch:{branchId}` - Dilemma's branches
- `dilemma:{dilemmaId}:comment:{commentId}` - Dilemma's comments

## AI Generation

The AI outcome tree generation uses GPT-4o with a specialized prompt:

```
System: Expert in decision analysis and ethical reasoning
Task: Generate outcome tree as JSON array
Structure: root node (depth 0) → main branches (depth 1) → consequences (depth 2)
Output: [{ id, parent_id, content, outcome, probability, impact, depth }]
```

### Example Tree Structure
```
Root: "Should we expand internationally?"
├── Branch 1: "Expand to Europe" (prob: 60, impact: 8)
│   ├── "Successful market entry" (prob: 70, impact: 9)
│   └── "Regulatory challenges" (prob: 30, impact: 6)
├── Branch 2: "Expand to Asia" (prob: 50, impact: 9)
│   ├── "High growth potential" (prob: 65, impact: 10)
│   └── "Cultural barriers" (prob: 35, impact: 7)
└── Branch 3: "Stay domestic" (prob: 80, impact: 5)
    ├── "Stable but limited growth" (prob: 85, impact: 5)
    └── "Market saturation" (prob: 15, impact: 4)
```

## Design System

### Colors
- **Deep Blue**: `#1E40AF` - Primary actions, navigation
- **Sage Green**: `#10B981` - Success, positive votes
- **Warm Orange**: `#F59E0B` - Highlights, impact scores
- **Gray**: Various shades for text and backgrounds

### Typography
- **Headings**: Inter font family
- **Body**: Source Sans Pro
- **Responsive**: Mobile-first approach

## Troubleshooting

### Outcome Tree Not Showing
1. Check browser console for errors
2. Verify dilemma status is "published" in database
3. Ensure branches were saved (check server logs)
4. Refresh the page to reload branches

### AI Generation Fails
1. Verify OPENAI_API_KEY is set in Supabase environment
2. Check OpenAI API quota and billing
3. Review server logs for detailed error messages
4. Try again - occasional API timeouts can occur

### Authentication Issues
1. Clear localStorage and try again
2. Check Supabase Auth settings
3. Verify email confirmation is set to automatic
4. Check server logs for auth errors

## Performance

- **Fast Load Times**: Optimized React components
- **Efficient Rendering**: React Flow handles large trees (50+ nodes)
- **Lazy Loading**: Images and components loaded on demand
- **Caching**: Supabase client singleton pattern

## Security

- **Authentication**: Supabase Auth with JWTs
- **Authorization**: Server-side token validation
- **Protected Routes**: Client-side route guards
- **API Security**: Service role key never exposed to frontend
- **Input Validation**: Server-side validation for all endpoints

## Future Enhancements

- [ ] Evidence attachments for branches
- [ ] Collaborative editing
- [ ] Export to PDF/PNG
- [ ] Advanced analytics dashboard
- [ ] Social login (Google, GitHub)
- [ ] Email notifications
- [ ] Branch editing after creation
- [ ] Multi-language support
- [ ] Dark mode

## Contributing

This is a prototype project built with Figma Make. Feel free to:
- Report issues
- Suggest features
- Fork and modify for your needs

## License

MIT License - See LICENSE file for details

## Acknowledgments

- Built with [Figma Make](https://www.figma.com)
- Powered by [Supabase](https://supabase.com)
- AI by [OpenAI](https://openai.com)
- UI Components from [Shadcn/UI](https://ui.shadcn.com)

---

**DilemmaTree** - Visualize decisions, explore consequences, make better choices 🌳
