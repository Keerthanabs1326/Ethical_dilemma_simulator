import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { Hono } from 'npm:hono';
import { cors } from 'npm:hono/cors';
import { logger } from 'npm:hono/logger';
import { createClient } from 'npm:@supabase/supabase-js@2';
import * as kv from './kv_store.tsx';

const app = new Hono();

// Middleware
app.use('*', cors());
app.use('*', logger(console.log));

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL')!,
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
);

// Initialize storage bucket
async function initializeBucket() {
  const bucketName = 'make-a0cbdfb4-evidence';
  const { data: buckets } = await supabase.storage.listBuckets();
  const bucketExists = buckets?.some(bucket => bucket.name === bucketName);
  
  if (!bucketExists) {
    const { error } = await supabase.storage.createBucket(bucketName, { public: false });
    if (error) console.log('Error creating bucket:', error);
  }
}

initializeBucket();

// Authentication middleware
async function requireAuth(c: any, next: () => Promise<void>) {
  const accessToken = c.req.header('Authorization')?.split(' ')[1];
  const { data: { user }, error } = await supabase.auth.getUser(accessToken);
  
  if (!user || error) {
    return c.json({ error: 'Unauthorized' }, 401);
  }
  
  c.set('userId', user.id);
  c.set('userEmail', user.email);
  await next();
}

// ============ AUTH ROUTES ============

// Sign up
app.post('/make-server-a0cbdfb4/auth/signup', async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: 'Missing required fields' }, 400);
    }
    
    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      email_confirm: true // Automatically confirm since email server not configured
    });
    
    if (error) {
      console.log('Sign up error:', error);
      return c.json({ error: error.message }, 400);
    }
    
    // Create user profile
    await kv.set(`user:${data.user.id}`, {
      id: data.user.id,
      email,
      name,
      avatar: '',
      reputation: 0,
      created_at: new Date().toISOString()
    });
    
    return c.json({ user: data.user });
  } catch (error) {
    console.error('Sign up error details:', error);
    return c.json({ error: 'Sign up failed', details: String(error) }, 500);
  }
});

// Get current user profile
app.get('/make-server-a0cbdfb4/auth/me', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const user = await kv.get(`user:${userId}`);
    
    if (!user) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    return c.json({ user });
  } catch (error) {
    console.error('Get current user error details:', error);
    return c.json({ error: 'Failed to get user', details: String(error) }, 500);
  }
});

// ============ DILEMMA ROUTES ============

// Create dilemma
app.post('/make-server-a0cbdfb4/dilemmas', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const { title, description, category } = await c.req.json();
    
    if (!title || !description) {
      return c.json({ error: 'Missing required fields' }, 400);
    }
    
    const dilemmaId = crypto.randomUUID();
    const dilemma = {
      id: dilemmaId,
      title,
      description,
      category: category || 'general',
      creator_id: userId,
      created_at: new Date().toISOString(),
      views: 0,
      votes_up: 0,
      votes_down: 0,
      status: 'draft'
    };
    
    await kv.set(`dilemma:${dilemmaId}`, dilemma);
    await kv.set(`user:${userId}:dilemma:${dilemmaId}`, dilemmaId);
    
    return c.json({ dilemma });
  } catch (error) {
    console.error('Create dilemma error details:', error);
    return c.json({ error: 'Failed to create dilemma', details: String(error) }, 500);
  }
});

// Generate AI outcome tree
app.post('/make-server-a0cbdfb4/dilemmas/:id/generate-tree', requireAuth, async (c) => {
  try {
    const dilemmaId = c.req.param('id');
    const { dilemma } = await c.req.json();
    
    console.log(`Generating AI tree for dilemma ${dilemmaId}: ${dilemma.title}`);
    
    const openaiKey = Deno.env.get('OPENAI_API_KEY');
    if (!openaiKey) {
      console.error('OpenAI API key not configured');
      return c.json({ error: 'OpenAI API key not configured' }, 500);
    }
    
    // Call OpenAI API
    const response = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${openaiKey}`
      },
      body: JSON.stringify({
        model: 'gpt-4o',
        messages: [
          {
            role: 'system',
            content: 'You are an expert in decision analysis and ethical reasoning. Generate a comprehensive outcome tree for dilemmas. You MUST respond with ONLY valid JSON - no markdown code blocks, no explanations. Return a JSON array of branches with this exact structure: [{ "id": "unique-id", "parent_id": null or "parent-id", "content": "decision or outcome description", "outcome": "detailed consequence", "probability": number 0-100, "impact": number 1-10, "depth": number 0-3 }]. The first node MUST have parent_id: null and depth: 0.'
          },
          {
            role: 'user',
            content: `Generate an outcome tree for this dilemma:\n\nTitle: ${dilemma.title}\nDescription: ${dilemma.description}\n\nCreate a decision tree with:\n1. ONE root node (depth: 0, parent_id: null) that represents the initial dilemma\n2. 3-4 main decision options branching from the root (depth: 1, parent_id: root node id)\n3. 2-3 consequence branches for each decision (depth: 2, parent_id: decision node id)\n\nUse realistic probability estimates (0-100) and impact scores (1-10). Respond with ONLY the JSON array, no other text.`
          }
        ],
        temperature: 0.7,
        max_tokens: 3000
      })
    });
    
    const result = await response.json();
    
    if (!response.ok) {
      console.error('OpenAI API error:', result);
      return c.json({ error: 'AI generation failed', details: result }, 500);
    }
    
    const content = result.choices[0].message.content;
    console.log('AI Response content:', content.substring(0, 200));
    
    let branches;
    
    try {
      // Try to extract JSON from markdown code blocks if present
      let jsonString = content;
      const jsonMatch = content.match(/```json\n([\s\S]*?)\n```/) || content.match(/```\n([\s\S]*?)\n```/);
      if (jsonMatch) {
        jsonString = jsonMatch[1];
      }
      
      // Clean up the string
      jsonString = jsonString.trim();
      
      branches = JSON.parse(jsonString);
      console.log(`Parsed ${branches.length} branches from AI response`);
    } catch (e) {
      console.error('JSON parse error:', e);
      console.error('Content that failed to parse:', content);
      return c.json({ error: 'Failed to parse AI response', details: String(e) }, 500);
    }
    
    // Validate branches is an array
    if (!Array.isArray(branches)) {
      console.error('AI response is not an array:', branches);
      return c.json({ error: 'AI response is not a valid array' }, 500);
    }
    
    // Save branches to database
    console.log(`Saving ${branches.length} branches to database...`);
    for (const branch of branches) {
      const branchId = branch.id || crypto.randomUUID();
      await kv.set(`branch:${branchId}`, {
        id: branchId,
        dilemma_id: dilemmaId,
        parent_branch_id: branch.parent_id,
        content: branch.content,
        outcome: branch.outcome || '',
        probability: branch.probability || 50,
        impact: branch.impact || 5,
        depth: branch.depth || 0,
        votes_up: 0,
        votes_down: 0,
        created_at: new Date().toISOString()
      });
      await kv.set(`dilemma:${dilemmaId}:branch:${branchId}`, branchId);
    }
    
    // Update dilemma status
    const dilemmaData = await kv.get(`dilemma:${dilemmaId}`);
    if (dilemmaData) {
      dilemmaData.status = 'published';
      await kv.set(`dilemma:${dilemmaId}`, dilemmaData);
      console.log(`Dilemma ${dilemmaId} status updated to published`);
    }
    
    console.log(`Successfully generated and saved tree for dilemma ${dilemmaId}`);
    return c.json({ branches });
  } catch (error) {
    console.error('Generate tree error details:', error);
    return c.json({ error: 'Failed to generate tree', details: String(error) }, 500);
  }
});

// Get all dilemmas
app.get('/make-server-a0cbdfb4/dilemmas', async (c) => {
  try {
    const allItems = await kv.getByPrefix('dilemma:');
    console.log(`Retrieved ${allItems.length} items with 'dilemma:' prefix`);
    
    // Filter to only include actual dilemma objects (not reference IDs)
    const dilemmas = allItems
      .filter(d => d && typeof d === 'object' && d.id && d.title)
      .filter(d => d.status === 'published')
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    
    console.log(`Filtered to ${dilemmas.length} published dilemmas`);
    return c.json({ dilemmas });
  } catch (error) {
    console.error('Get dilemmas error details:', error);
    return c.json({ error: 'Failed to get dilemmas', details: String(error) }, 500);
  }
});

// Get single dilemma
app.get('/make-server-a0cbdfb4/dilemmas/:id', async (c) => {
  try {
    const dilemmaId = c.req.param('id');
    const dilemma = await kv.get(`dilemma:${dilemmaId}`);
    
    if (!dilemma) {
      return c.json({ error: 'Dilemma not found' }, 404);
    }
    
    // Increment views
    dilemma.views = (dilemma.views || 0) + 1;
    await kv.set(`dilemma:${dilemmaId}`, dilemma);
    
    return c.json({ dilemma });
  } catch (error) {
    console.error('Get dilemma error details:', error);
    return c.json({ error: 'Failed to get dilemma', details: String(error) }, 500);
  }
});

// Get branches for a dilemma
app.get('/make-server-a0cbdfb4/dilemmas/:id/branches', async (c) => {
  try {
    const dilemmaId = c.req.param('id');
    const allBranches = await kv.getByPrefix(`branch:`);
    console.log(`Retrieved ${allBranches.length} branch items for dilemma ${dilemmaId}`);
    
    // Filter to only include actual branch objects for this dilemma
    const dilemmasBranches = allBranches.filter(b => 
      b && typeof b === 'object' && b.id && b.dilemma_id === dilemmaId
    );
    
    console.log(`Filtered to ${dilemmasBranches.length} branches for dilemma ${dilemmaId}`);
    return c.json({ branches: dilemmasBranches });
  } catch (error) {
    console.error('Get branches error details:', error);
    return c.json({ error: 'Failed to get branches', details: String(error) }, 500);
  }
});

// Get user's dilemmas
app.get('/make-server-a0cbdfb4/users/:userId/dilemmas', async (c) => {
  try {
    const userId = c.req.param('userId');
    const allItems = await kv.getByPrefix('dilemma:');
    console.log(`Retrieved ${allItems.length} items for user ${userId}`);
    
    // Filter to only include actual dilemma objects (not reference IDs)
    const userDilemmas = allItems
      .filter(d => d && typeof d === 'object' && d.id && d.title)
      .filter(d => d.creator_id === userId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    
    console.log(`Filtered to ${userDilemmas.length} dilemmas for user ${userId}`);
    return c.json({ dilemmas: userDilemmas });
  } catch (error) {
    console.error('Get user dilemmas error details:', error);
    return c.json({ error: 'Failed to get user dilemmas', details: String(error) }, 500);
  }
});

// ============ VOTING ROUTES ============

// Vote on dilemma or branch
app.post('/make-server-a0cbdfb4/vote', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const { dilemma_id, branch_id, vote_type } = await c.req.json();
    
    if (!dilemma_id || !vote_type || !['up', 'down'].includes(vote_type)) {
      return c.json({ error: 'Invalid vote data' }, 400);
    }
    
    const voteKey = branch_id 
      ? `vote:${userId}:branch:${branch_id}`
      : `vote:${userId}:dilemma:${dilemma_id}`;
    
    const existingVote = await kv.get(voteKey);
    
    // Update vote counts
    const target = branch_id 
      ? await kv.get(`branch:${branch_id}`)
      : await kv.get(`dilemma:${dilemma_id}`);
    
    if (!target) {
      return c.json({ error: 'Target not found' }, 404);
    }
    
    // Remove old vote if exists
    if (existingVote) {
      if (existingVote.vote_type === 'up') {
        target.votes_up = (target.votes_up || 1) - 1;
      } else {
        target.votes_down = (target.votes_down || 1) - 1;
      }
    }
    
    // Add new vote
    if (vote_type === 'up') {
      target.votes_up = (target.votes_up || 0) + 1;
    } else {
      target.votes_down = (target.votes_down || 0) + 1;
    }
    
    // Save updated target
    const targetKey = branch_id ? `branch:${branch_id}` : `dilemma:${dilemma_id}`;
    await kv.set(targetKey, target);
    
    // Save vote
    await kv.set(voteKey, {
      id: crypto.randomUUID(),
      user_id: userId,
      dilemma_id,
      branch_id: branch_id || null,
      vote_type,
      created_at: new Date().toISOString()
    });
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Vote error details:', error);
    return c.json({ error: 'Failed to vote', details: String(error) }, 500);
  }
});

// ============ COMMENT ROUTES ============

// Add comment
app.post('/make-server-a0cbdfb4/comments', requireAuth, async (c) => {
  try {
    const userId = c.get('userId');
    const { dilemma_id, branch_id, content } = await c.req.json();
    
    if (!dilemma_id || !content) {
      return c.json({ error: 'Missing required fields' }, 400);
    }
    
    const commentId = crypto.randomUUID();
    const comment = {
      id: commentId,
      user_id: userId,
      dilemma_id,
      branch_id: branch_id || null,
      content,
      created_at: new Date().toISOString()
    };
    
    await kv.set(`comment:${commentId}`, comment);
    await kv.set(`dilemma:${dilemma_id}:comment:${commentId}`, commentId);
    
    return c.json({ comment });
  } catch (error) {
    console.error('Add comment error details:', error);
    return c.json({ error: 'Failed to add comment', details: String(error) }, 500);
  }
});

// Get comments for dilemma
app.get('/make-server-a0cbdfb4/dilemmas/:id/comments', async (c) => {
  try {
    const dilemmaId = c.req.param('id');
    const allComments = await kv.getByPrefix('comment:');
    console.log(`Retrieved ${allComments.length} comment items for dilemma ${dilemmaId}`);
    
    // Filter to only include actual comment objects for this dilemma
    const dilemmaComments = allComments
      .filter(c => c && typeof c === 'object' && c.id && c.dilemma_id === dilemmaId)
      .sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    
    // Fetch user info for each comment
    const commentsWithUsers = await Promise.all(
      dilemmaComments.map(async (comment) => {
        const user = await kv.get(`user:${comment.user_id}`);
        return { ...comment, user };
      })
    );
    
    console.log(`Returning ${commentsWithUsers.length} comments with user data`);
    return c.json({ comments: commentsWithUsers });
  } catch (error) {
    console.error('Get comments error details:', error);
    return c.json({ error: 'Failed to get comments', details: String(error) }, 500);
  }
});

// ============ PROFILE ROUTES ============

// Get user profile
app.get('/make-server-a0cbdfb4/users/:userId', async (c) => {
  try {
    const userId = c.req.param('userId');
    const user = await kv.get(`user:${userId}`);
    
    if (!user) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    return c.json({ user });
  } catch (error) {
    console.error('Get user error details:', error);
    return c.json({ error: 'Failed to get user', details: String(error) }, 500);
  }
});

// Update user profile
app.put('/make-server-a0cbdfb4/users/:userId', requireAuth, async (c) => {
  try {
    const userId = c.req.param('userId');
    const authUserId = c.get('userId');
    
    if (userId !== authUserId) {
      return c.json({ error: 'Unauthorized' }, 403);
    }
    
    const { name, avatar } = await c.req.json();
    const user = await kv.get(`user:${userId}`);
    
    if (!user) {
      return c.json({ error: 'User not found' }, 404);
    }
    
    if (name) user.name = name;
    if (avatar !== undefined) user.avatar = avatar;
    
    await kv.set(`user:${userId}`, user);
    
    return c.json({ user });
  } catch (error) {
    console.error('Update user error details:', error);
    return c.json({ error: 'Failed to update user', details: String(error) }, 500);
  }
});

// Health check
app.get('/make-server-a0cbdfb4/health', (c) => {
  return c.json({ status: 'ok' });
});

Deno.serve(app.fetch);
