import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import { Toaster } from 'sonner';
import { ErrorBoundary } from './components/ErrorBoundary';
import { Header } from './components/Header';
import { Home } from './pages/Home';
import { Explore } from './pages/Explore';
import { Create } from './pages/Create';
import { Dashboard } from './pages/Dashboard';
import { DilemmaDetail } from './pages/DilemmaDetail';
import { Profile } from './pages/Profile';
import { Login } from './pages/Login';
import { Signup } from './pages/Signup';
import { Help } from './pages/Help';
import { authApi } from './utils/api';
import { createClient } from './utils/supabase-client';

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkUser();
  }, []);

  const checkUser = async () => {
    const token = localStorage.getItem('access_token');
    if (token) {
      const supabase = createClient();
      const { data } = await supabase.auth.getSession();
      
      if (data.session) {
        const { data: userData } = await authApi.getMe();
        if (userData && userData.user) {
          setUser(userData.user);
        }
      } else {
        localStorage.removeItem('access_token');
      }
    }
    setLoading(false);
  };

  const handleLogin = () => {
    checkUser();
  };

  const handleLogout = async () => {
    const supabase = createClient();
    await supabase.auth.signOut();
    localStorage.removeItem('access_token');
    setUser(null);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-[#1E40AF]"></div>
      </div>
    );
  }

  return (
    <ErrorBoundary>
      <Router>
        <div className="min-h-screen bg-white">
          <Header user={user} onLogout={handleLogout} />
          
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/explore" element={<Explore />} />
            <Route path="/create" element={user ? <Create /> : <Navigate to="/login" />} />
            <Route path="/dashboard" element={<Dashboard user={user} />} />
            <Route path="/dilemma/:id" element={<DilemmaDetail />} />
            <Route path="/profile/:userId" element={<Profile />} />
            <Route path="/profile" element={user ? <Navigate to={`/profile/${user.id}`} /> : <Navigate to="/login" />} />
            <Route path="/login" element={<Login onLogin={handleLogin} />} />
            <Route path="/signup" element={<Signup onLogin={handleLogin} />} />
            <Route path="/help" element={<Help />} />
            <Route path="*" element={<Navigate to="/" />} />
          </Routes>

          <Toaster position="top-right" richColors />
        </div>
      </Router>
    </ErrorBoundary>
  );
}