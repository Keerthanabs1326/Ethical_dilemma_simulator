import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { User, Mail, Calendar, Award, TrendingUp } from 'lucide-react';
import { Card } from '../components/ui/card';
import { DilemmaCard } from '../components/DilemmaCard';
import { usersApi, dilemmasApi } from '../utils/api';

export function Profile() {
  const { userId } = useParams();
  const [user, setUser] = useState<any>(null);
  const [dilemmas, setDilemmas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (userId) {
      loadProfile();
    }
  }, [userId]);

  const loadProfile = async () => {
    setLoading(true);
    
    const { data: userData } = await usersApi.getById(userId!);
    if (userData && userData.user) {
      setUser(userData.user);
    }

    const { data: dilemmasData } = await dilemmasApi.getUserDilemmas(userId!);
    if (dilemmasData && dilemmasData.dilemmas) {
      setDilemmas(dilemmasData.dilemmas);
    }

    setLoading(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-32 bg-gray-200 rounded mb-4" />
            <div className="h-64 bg-gray-200 rounded" />
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600">User not found</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        {/* Profile Header */}
        <Card className="p-8 mb-8">
          <div className="flex items-start gap-6">
            <div className="flex-shrink-0">
              <div className="w-24 h-24 rounded-full bg-gradient-to-br from-[#1E40AF] to-[#10B981] flex items-center justify-center">
                <User className="h-12 w-12 text-white" />
              </div>
            </div>
            
            <div className="flex-1">
              <h1 className="mb-2">{user.name}</h1>
              
              <div className="flex flex-col gap-2 text-gray-600 mb-4">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  <span>{user.email}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4" />
                  <span>Joined {new Date(user.created_at).toLocaleDateString()}</span>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div className="flex items-center gap-2">
                  <Award className="h-5 w-5 text-[#F59E0B]" />
                  <span>
                    <span className="font-semibold">{user.reputation || 0}</span>{' '}
                    <span className="text-gray-600">Reputation</span>
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-[#10B981]" />
                  <span>
                    <span className="font-semibold">{dilemmas.length}</span>{' '}
                    <span className="text-gray-600">Dilemmas</span>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </Card>

        {/* User's Dilemmas */}
        <div className="mb-4">
          <h2>Dilemmas by {user.name}</h2>
        </div>

        {dilemmas.length > 0 ? (
          <div className="grid md:grid-cols-2 gap-6">
            {dilemmas.map((dilemma) => (
              <DilemmaCard key={dilemma.id} dilemma={dilemma} />
            ))}
          </div>
        ) : (
          <Card className="p-12 text-center">
            <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">This user hasn't created any dilemmas yet</p>
          </Card>
        )}
      </div>
    </div>
  );
}
