import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Brain, Sparkles, Users, TrendingUp, ArrowRight } from 'lucide-react';
import { Button } from '../components/ui/button';
import { DilemmaCard } from '../components/DilemmaCard';
import { dilemmasApi } from '../utils/api';

export function Home() {
  const [featuredDilemmas, setFeaturedDilemmas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadFeaturedDilemmas();
  }, []);

  const loadFeaturedDilemmas = async () => {
    setLoading(true);
    const { data, error } = await dilemmasApi.getAll();
    if (data && data.dilemmas) {
      setFeaturedDilemmas(data.dilemmas.slice(0, 6));
    }
    setLoading(false);
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-[#1E40AF] via-[#1E40AF]/90 to-[#10B981] text-white py-20 md:py-32">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-white/20 backdrop-blur-sm px-4 py-2 rounded-full mb-8">
              <Sparkles className="h-4 w-4" />
              <span className="text-sm">AI-Powered Decision Intelligence</span>
            </div>
            
            <h1 className="mb-6">
              Navigate Complex Decisions with Clarity
            </h1>
            
            <p className="text-xl mb-10 text-white/90">
              DilemmaTree uses AI to map ethical and strategic dilemmas into interactive consequence trees.
              Explore outcomes, collaborate with others, and make informed decisions.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/create">
                <Button size="lg" className="bg-white text-[#1E40AF] hover:bg-white/90 gap-2">
                  Create Your First Dilemma
                  <ArrowRight className="h-5 w-5" />
                </Button>
              </Link>
              <Link to="/explore">
                <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                  Explore Dilemmas
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="mb-4">How DilemmaTree Works</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">
              Our AI-powered platform helps you visualize complex decisions and their cascading consequences
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-[#1E40AF]/10 rounded-xl mb-4">
                <Brain className="h-8 w-8 text-[#1E40AF]" />
              </div>
              <h3 className="mb-2">Create Dilemmas</h3>
              <p className="text-gray-600">
                Describe your ethical or strategic dilemma using our intuitive creation wizard
              </p>
            </div>

            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-[#10B981]/10 rounded-xl mb-4">
                <Sparkles className="h-8 w-8 text-[#10B981]" />
              </div>
              <h3 className="mb-2">AI Analysis</h3>
              <p className="text-gray-600">
                GPT-4o generates a comprehensive outcome tree exploring multiple decision paths
              </p>
            </div>

            <div className="text-center p-6">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-[#F59E0B]/10 rounded-xl mb-4">
                <Users className="h-8 w-8 text-[#F59E0B]" />
              </div>
              <h3 className="mb-2">Collaborate</h3>
              <p className="text-gray-600">
                Vote, comment, and share insights with the community in real-time
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Dilemmas */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-10">
            <div>
              <h2 className="mb-2">Featured Dilemmas</h2>
              <p className="text-gray-600">Explore recent dilemmas from the community</p>
            </div>
            <Link to="/explore">
              <Button variant="outline" className="gap-2">
                View All
                <ArrowRight className="h-4 w-4" />
              </Button>
            </Link>
          </div>

          {loading ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-48 bg-white rounded-lg animate-pulse" />
              ))}
            </div>
          ) : featuredDilemmas.length > 0 ? (
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {featuredDilemmas.map((dilemma) => (
                <DilemmaCard key={dilemma.id} dilemma={dilemma} />
              ))}
            </div>
          ) : (
            <div className="text-center py-12 bg-white rounded-lg border-2 border-dashed border-gray-300">
              <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">No dilemmas yet. Be the first to create one!</p>
              <Link to="/create">
                <Button className="bg-[#1E40AF] hover:bg-[#1E40AF]/90">
                  Create Dilemma
                </Button>
              </Link>
            </div>
          )}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-[#1E40AF] to-[#10B981] text-white">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="mb-4">Ready to Map Your Next Decision?</h2>
          <p className="text-xl mb-8 text-white/90 max-w-2xl mx-auto">
            Join our community and start visualizing complex choices with AI-powered insights
          </p>
          <Link to="/create">
            <Button size="lg" className="bg-white text-[#1E40AF] hover:bg-white/90 gap-2">
              Get Started Free
              <ArrowRight className="h-5 w-5" />
            </Button>
          </Link>
        </div>
      </section>
    </div>
  );
}
