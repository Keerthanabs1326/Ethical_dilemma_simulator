import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, TrendingUp } from 'lucide-react';
import { Button } from '../components/ui/button';
import { DilemmaCard } from '../components/DilemmaCard';
import { dilemmasApi } from '../utils/api';

interface DashboardProps {
  user: any;
}

export function Dashboard({ user }: DashboardProps) {
  const [dilemmas, setDilemmas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadUserDilemmas();
    }
  }, [user]);

  const loadUserDilemmas = async () => {
    setLoading(true);
    const { data, error } = await dilemmasApi.getUserDilemmas(user.id);
    if (data && data.dilemmas) {
      setDilemmas(data.dilemmas);
    }
    setLoading(false);
  };

  if (!user) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600 mb-4">Please log in to view your dashboard</p>
          <Link to="/login">
            <Button className="bg-[#1E40AF] hover:bg-[#1E40AF]/90">Login</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="mb-2">My Dashboard</h1>
            <p className="text-gray-600">
              Manage your dilemmas and track engagement
            </p>
          </div>
          <Link to="/create">
            <Button className="bg-[#1E40AF] hover:bg-[#1E40AF]/90 gap-2">
              <Plus className="h-4 w-4" />
              Create Dilemma
            </Button>
          </Link>
        </div>

        {/* Stats Cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="text-sm text-gray-600 mb-1">Total Dilemmas</div>
            <div className="text-3xl text-[#1E40AF]">{dilemmas.length}</div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="text-sm text-gray-600 mb-1">Total Views</div>
            <div className="text-3xl text-[#10B981]">
              {dilemmas.reduce((sum, d) => sum + (d.views || 0), 0)}
            </div>
          </div>
          <div className="bg-white p-6 rounded-lg shadow-sm border">
            <div className="text-sm text-gray-600 mb-1">Reputation</div>
            <div className="text-3xl text-[#F59E0B]">{user.reputation || 0}</div>
          </div>
        </div>

        {/* My Dilemmas */}
        <div className="mb-4">
          <h2>My Dilemmas</h2>
        </div>

        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3].map((i) => (
              <div key={i} className="h-48 bg-white rounded-lg animate-pulse" />
            ))}
          </div>
        ) : dilemmas.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {dilemmas.map((dilemma) => (
              <DilemmaCard key={dilemma.id} dilemma={dilemma} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-lg border-2 border-dashed border-gray-300">
            <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600 mb-4">You haven't created any dilemmas yet</p>
            <Link to="/create">
              <Button className="bg-[#1E40AF] hover:bg-[#1E40AF]/90 gap-2">
                <Plus className="h-4 w-4" />
                Create Your First Dilemma
              </Button>
            </Link>
          </div>
        )}
      </div>
    </div>
  );
}
