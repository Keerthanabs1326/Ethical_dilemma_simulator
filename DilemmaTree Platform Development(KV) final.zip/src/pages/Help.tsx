import { Brain, Sparkles, GitBranch, Users, MessageCircle, ThumbsUp, Share2 } from 'lucide-react';
import { Card } from '../components/ui/card';
import { Link } from 'react-router-dom';
import { Button } from '../components/ui/button';
import { SystemStatus } from '../components/SystemStatus';

export function Help() {
  const faqs = [
    {
      question: 'What is DilemmaTree?',
      answer: 'DilemmaTree is an AI-powered platform that helps you visualize and analyze complex ethical and strategic decisions. It uses GPT-4o to generate comprehensive outcome trees showing different decision paths and their potential consequences.',
    },
    {
      question: 'How do I create a dilemma?',
      answer: 'Click on "Create" in the navigation menu, fill in your dilemma details including a title, description, and category. Our AI will then generate a detailed outcome tree exploring multiple decision paths and their consequences.',
    },
    {
      question: 'What is an outcome tree?',
      answer: 'An outcome tree is an interactive visualization that maps out different decision paths and their cascading consequences. Each branch represents a possible choice or outcome, with probability and impact scores to help you evaluate options.',
    },
    {
      question: 'How does voting work?',
      answer: 'You can vote on dilemmas and individual branches to indicate agreement or usefulness. Votes help highlight the most valuable insights and build community consensus around different decision paths.',
    },
    {
      question: 'Can I collaborate with others?',
      answer: 'Yes! You can comment on dilemmas, vote on different outcomes, and share your insights with the community. All interactions happen in real-time, making DilemmaTree a collaborative decision-making platform.',
    },
    {
      question: 'What is reputation?',
      answer: 'Reputation is earned when other users find your dilemmas and contributions valuable. Higher reputation indicates active and helpful community participation.',
    },
  ];

  const features = [
    {
      icon: Brain,
      title: 'AI-Powered Analysis',
      description: 'GPT-4o generates comprehensive outcome trees exploring multiple decision paths',
      color: 'text-[#1E40AF]',
      bg: 'bg-[#1E40AF]/10',
    },
    {
      icon: GitBranch,
      title: 'Interactive Visualization',
      description: 'Explore decision trees with probability and impact scores for each outcome',
      color: 'text-[#10B981]',
      bg: 'bg-[#10B981]/10',
    },
    {
      icon: Users,
      title: 'Community Collaboration',
      description: 'Vote, comment, and share insights with others facing similar decisions',
      color: 'text-[#F59E0B]',
      bg: 'bg-[#F59E0B]/10',
    },
    {
      icon: Share2,
      title: 'Export & Share',
      description: 'Export dilemmas as JSON or share links to collaborate with your team',
      color: 'text-purple-600',
      bg: 'bg-purple-100',
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-5xl">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="mb-4">Help Center</h1>
          <p className="text-gray-600 text-xl">
            Everything you need to know about using DilemmaTree
          </p>
        </div>

        {/* System Status */}
        <div className="mb-12">
          <SystemStatus />
        </div>

        {/* Quick Start */}
        <Card className="p-8 mb-12 bg-gradient-to-br from-[#1E40AF]/5 to-[#10B981]/5 border-[#1E40AF]/20">
          <h2 className="mb-6 flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-[#1E40AF]" />
            Quick Start Guide
          </h2>
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-full bg-[#1E40AF] text-white flex items-center justify-center font-semibold">
                1
              </div>
              <h3>Create Account</h3>
              <p className="text-gray-600">Sign up to start creating and exploring dilemmas</p>
            </div>
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-full bg-[#10B981] text-white flex items-center justify-center font-semibold">
                2
              </div>
              <h3>Describe Dilemma</h3>
              <p className="text-gray-600">Use the creation wizard to describe your decision challenge</p>
            </div>
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-full bg-[#F59E0B] text-white flex items-center justify-center font-semibold">
                3
              </div>
              <h3>Explore Tree</h3>
              <p className="text-gray-600">AI generates an outcome tree you can explore and share</p>
            </div>
          </div>
        </Card>

        {/* Features */}
        <div className="mb-12">
          <h2 className="mb-6">Key Features</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="p-6">
                  <div className={`w-12 h-12 rounded-lg ${feature.bg} flex items-center justify-center mb-4`}>
                    <Icon className={`h-6 w-6 ${feature.color}`} />
                  </div>
                  <h3 className="mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </Card>
              );
            })}
          </div>
        </div>

        {/* FAQs */}
        <div className="mb-12">
          <h2 className="mb-6">Frequently Asked Questions</h2>
          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <Card key={index} className="p-6">
                <h3 className="mb-2">{faq.question}</h3>
                <p className="text-gray-600">{faq.answer}</p>
              </Card>
            ))}
          </div>
        </div>

        {/* How to Use */}
        <div className="mb-12">
          <h2 className="mb-6">How to Use DilemmaTree</h2>
          
          <div className="space-y-8">
            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#1E40AF]/10 flex items-center justify-center">
                  <Brain className="h-5 w-5 text-[#1E40AF]" />
                </div>
                <div>
                  <h3 className="mb-2">Creating a Dilemma</h3>
                  <p className="text-gray-600 mb-3">
                    Navigate to the Create page and use our step-by-step wizard. Provide a clear title and detailed description of your dilemma. The more context you provide, the better the AI can analyze different decision paths.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#10B981]/10 flex items-center justify-center">
                  <GitBranch className="h-5 w-5 text-[#10B981]" />
                </div>
                <div>
                  <h3 className="mb-2">Understanding the Tree</h3>
                  <p className="text-gray-600 mb-3">
                    Each node in the tree represents a decision or outcome. Probability scores (0-100%) indicate likelihood, while impact scores (1-10) show potential significance. Click on nodes to see details and navigate the tree.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-[#F59E0B]/10 flex items-center justify-center">
                  <ThumbsUp className="h-5 w-5 text-[#F59E0B]" />
                </div>
                <div>
                  <h3 className="mb-2">Voting & Commenting</h3>
                  <p className="text-gray-600 mb-3">
                    Vote on dilemmas and individual branches to indicate agreement or usefulness. Add comments to share your insights, ask questions, or provide additional context. This helps the community learn from collective wisdom.
                  </p>
                </div>
              </div>
            </Card>

            <Card className="p-6">
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 w-10 h-10 rounded-lg bg-purple-100 flex items-center justify-center">
                  <Share2 className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="mb-2">Sharing & Exporting</h3>
                  <p className="text-gray-600 mb-3">
                    Share dilemmas by copying the URL. Export dilemmas as JSON files to integrate with other tools or save for offline analysis. All data exports include the full tree structure and community feedback.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>

        {/* CTA */}
        <Card className="p-8 text-center bg-gradient-to-r from-[#1E40AF] to-[#10B981] text-white">
          <h2 className="mb-4">Ready to Get Started?</h2>
          <p className="mb-6 text-white/90">
            Create your first dilemma and see how AI can help you make better decisions
          </p>
          <Link to="/create">
            <Button size="lg" className="bg-white text-[#1E40AF] hover:bg-white/90">
              Create Your First Dilemma
            </Button>
          </Link>
        </Card>
      </div>
    </div>
  );
}