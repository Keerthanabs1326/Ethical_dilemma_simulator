import { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, ThumbsUp, ThumbsDown, MessageCircle, Share2, Download, Eye, User as UserIcon } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Card } from '../components/ui/card';
import { Textarea } from '../components/ui/textarea';
import { OutcomeTreeFlow } from '../components/OutcomeTreeFlow';
import { dilemmasApi, votingApi, commentsApi, usersApi } from '../utils/api';
import { toast } from 'sonner';

export function DilemmaDetail() {
  const { id } = useParams();
  const [dilemma, setDilemma] = useState<any>(null);
  const [branches, setBranches] = useState<any[]>([]);
  const [comments, setComments] = useState<any[]>([]);
  const [creator, setCreator] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [newComment, setNewComment] = useState('');
  const [selectedBranch, setSelectedBranch] = useState<any>(null);

  useEffect(() => {
    if (id) {
      loadDilemma();
      loadBranches();
      loadComments();
    }
  }, [id]);

  const loadDilemma = async () => {
    const { data, error } = await dilemmasApi.getById(id!);
    if (error) {
      console.error('Error loading dilemma:', error);
    }
    if (data && data.dilemma) {
      console.log('Loaded dilemma:', data.dilemma);
      setDilemma(data.dilemma);
      // Load creator info
      const { data: userData } = await usersApi.getById(data.dilemma.creator_id);
      if (userData && userData.user) {
        setCreator(userData.user);
      }
    }
    setLoading(false);
  };

  const loadBranches = async () => {
    const { data, error } = await dilemmasApi.getBranches(id!);
    if (error) {
      console.error('Error loading branches:', error);
    }
    if (data && data.branches) {
      console.log(`Loaded ${data.branches.length} branches for dilemma ${id}`);
      setBranches(data.branches);
    }
  };

  const loadComments = async () => {
    const { data, error } = await dilemmasApi.getComments(id!);
    if (data && data.comments) {
      setComments(data.comments);
    }
  };

  const handleVote = async (voteType: 'up' | 'down') => {
    const { error } = await votingApi.vote(id!, voteType);
    if (error) {
      toast.error('Please log in to vote');
    } else {
      toast.success('Vote recorded!');
      loadDilemma();
    }
  };

  const handleBranchVote = async (branchId: string, voteType: 'up' | 'down') => {
    const { error } = await votingApi.vote(id!, voteType, branchId);
    if (error) {
      toast.error('Please log in to vote');
    } else {
      toast.success('Vote recorded!');
      loadBranches();
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;

    const { error } = await commentsApi.create(id!, newComment, selectedBranch?.id);
    if (error) {
      toast.error('Please log in to comment');
    } else {
      toast.success('Comment added!');
      setNewComment('');
      loadComments();
    }
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Link copied to clipboard!');
  };

  const handleExport = () => {
    const exportData = {
      dilemma,
      branches,
      comments,
    };
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = `dilemma-${id}.json`;
    
    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    
    toast.success('Dilemma exported!');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-200 rounded w-1/3 mb-4" />
            <div className="h-64 bg-gray-200 rounded mb-4" />
          </div>
        </div>
      </div>
    );
  }

  if (!dilemma) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p className="text-gray-600">Dilemma not found</p>
          <Link to="/explore">
            <Button className="mt-4">Back to Explore</Button>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link to="/explore">
          <Button variant="ghost" className="mb-6 gap-2">
            <ArrowLeft className="h-4 w-4" />
            Back to Explore
          </Button>
        </Link>

        {/* Header */}
        <Card className="p-6 mb-6">
          <div className="flex items-start justify-between gap-4 mb-4">
            <div className="flex-1">
              <div className="flex items-center gap-3 mb-3">
                <span className="px-3 py-1 bg-[#1E40AF]/10 text-[#1E40AF] rounded-full text-sm">
                  {dilemma.category}
                </span>
                {creator && (
                  <Link to={`/profile/${creator.id}`} className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900">
                    <UserIcon className="h-4 w-4" />
                    <span>by {creator.name}</span>
                  </Link>
                )}
              </div>
              <h1 className="mb-3">{dilemma.title}</h1>
              <p className="text-gray-700 mb-4">{dilemma.description}</p>
              
              {/* Stats */}
              <div className="flex items-center gap-6 text-sm text-gray-600">
                <div className="flex items-center gap-1">
                  <Eye className="h-4 w-4" />
                  <span>{dilemma.views || 0} views</span>
                </div>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => handleVote('up')}
                    className="flex items-center gap-1 text-[#10B981] hover:opacity-70 transition-opacity"
                  >
                    <ThumbsUp className="h-4 w-4" />
                    <span>{dilemma.votes_up || 0}</span>
                  </button>
                  <button
                    onClick={() => handleVote('down')}
                    className="flex items-center gap-1 text-gray-400 hover:opacity-70 transition-opacity"
                  >
                    <ThumbsDown className="h-4 w-4" />
                    <span>{dilemma.votes_down || 0}</span>
                  </button>
                </div>
                <div className="flex items-center gap-1">
                  <MessageCircle className="h-4 w-4" />
                  <span>{comments.length} comments</span>
                </div>
              </div>
            </div>

            {/* Actions */}
            <div className="flex gap-2">
              <Button variant="outline" size="sm" onClick={handleShare} className="gap-2">
                <Share2 className="h-4 w-4" />
                Share
              </Button>
              <Button variant="outline" size="sm" onClick={handleExport} className="gap-2">
                <Download className="h-4 w-4" />
                Export
              </Button>
            </div>
          </div>
        </Card>

        {/* Outcome Tree */}
        <Card className="p-6 mb-6">
          <h2 className="mb-4">Outcome Tree</h2>
          <OutcomeTreeFlow
            branches={branches}
            onNodeClick={(branch) => setSelectedBranch(branch)}
            onVote={handleBranchVote}
          />
          
          {selectedBranch && (
            <div className="mt-6 p-4 bg-[#1E40AF]/5 rounded-lg border border-[#1E40AF]/20">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm text-[#1E40AF]">Selected Branch</span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setSelectedBranch(null)}
                >
                  Clear
                </Button>
              </div>
              <p>{selectedBranch.content}</p>
              {selectedBranch.outcome && (
                <p className="text-sm text-gray-600 mt-1">→ {selectedBranch.outcome}</p>
              )}
            </div>
          )}
        </Card>

        {/* Comments Section */}
        <Card className="p-6">
          <h2 className="mb-4">Discussion ({comments.length})</h2>
          
          {/* Add Comment */}
          <div className="mb-6">
            <Textarea
              placeholder="Share your thoughts or insights..."
              value={newComment}
              onChange={(e) => setNewComment(e.target.value)}
              className="mb-2"
            />
            <Button
              onClick={handleAddComment}
              disabled={!newComment.trim()}
              className="bg-[#1E40AF] hover:bg-[#1E40AF]/90"
            >
              Add Comment
            </Button>
          </div>

          {/* Comments List */}
          <div className="space-y-4">
            {comments.length > 0 ? (
              comments.map((comment) => (
                <div key={comment.id} className="border-b pb-4">
                  <div className="flex items-center gap-2 mb-2">
                    <UserIcon className="h-4 w-4 text-gray-400" />
                    <span>{comment.user?.name || 'Anonymous'}</span>
                    <span className="text-sm text-gray-500">
                      • {new Date(comment.created_at).toLocaleDateString()}
                    </span>
                  </div>
                  <p className="text-gray-700">{comment.content}</p>
                </div>
              ))
            ) : (
              <p className="text-gray-500 text-center py-8">
                No comments yet. Be the first to share your thoughts!
              </p>
            )}
          </div>
        </Card>
      </div>
    </div>
  );
}
