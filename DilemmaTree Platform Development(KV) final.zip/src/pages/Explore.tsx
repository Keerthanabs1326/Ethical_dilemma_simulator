import { useEffect, useState } from 'react';
import { Search, Filter, TrendingUp } from 'lucide-react';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { DilemmaCard } from '../components/DilemmaCard';
import { dilemmasApi } from '../utils/api';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';

export function Explore() {
  const [dilemmas, setDilemmas] = useState<any[]>([]);
  const [filteredDilemmas, setFilteredDilemmas] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  useEffect(() => {
    loadDilemmas();
  }, []);

  useEffect(() => {
    filterAndSortDilemmas();
  }, [dilemmas, searchQuery, categoryFilter, sortBy]);

  const loadDilemmas = async () => {
    setLoading(true);
    const { data, error } = await dilemmasApi.getAll();
    if (error) {
      console.error('Error loading dilemmas:', error);
    }
    if (data && data.dilemmas) {
      console.log(`Loaded ${data.dilemmas.length} dilemmas`);
      setDilemmas(data.dilemmas);
    }
    setLoading(false);
  };

  const filterAndSortDilemmas = () => {
    let filtered = [...dilemmas];

    // Search filter
    if (searchQuery) {
      filtered = filtered.filter(d =>
        d.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        d.description.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }

    // Category filter
    if (categoryFilter !== 'all') {
      filtered = filtered.filter(d => d.category === categoryFilter);
    }

    // Sort
    if (sortBy === 'recent') {
      filtered.sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    } else if (sortBy === 'popular') {
      filtered.sort((a, b) => (b.votes_up || 0) - (a.votes_up || 0));
    } else if (sortBy === 'views') {
      filtered.sort((a, b) => (b.views || 0) - (a.views || 0));
    }

    setFilteredDilemmas(filtered);
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <h1 className="mb-2">Explore Dilemmas</h1>
          <p className="text-gray-600">
            Browse and discover dilemmas from the community
          </p>
        </div>

        {/* Filters */}
        <div className="bg-white rounded-lg shadow-sm border p-6 mb-8">
          <div className="grid md:grid-cols-3 gap-4">
            {/* Search */}
            <div className="md:col-span-2">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
                <Input
                  type="text"
                  placeholder="Search dilemmas..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            {/* Category Filter */}
            <div>
              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="Category" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="ethical">Ethical</SelectItem>
                  <SelectItem value="strategic">Strategic</SelectItem>
                  <SelectItem value="personal">Personal</SelectItem>
                  <SelectItem value="business">Business</SelectItem>
                  <SelectItem value="general">General</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Sort */}
          <div className="flex items-center gap-2 mt-4 pt-4 border-t">
            <Filter className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-600">Sort by:</span>
            <div className="flex gap-2">
              <Button
                variant={sortBy === 'recent' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setSortBy('recent')}
                className={sortBy === 'recent' ? 'bg-[#1E40AF]' : ''}
              >
                Recent
              </Button>
              <Button
                variant={sortBy === 'popular' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setSortBy('popular')}
                className={sortBy === 'popular' ? 'bg-[#1E40AF]' : ''}
              >
                Popular
              </Button>
              <Button
                variant={sortBy === 'views' ? 'default' : 'ghost'}
                size="sm"
                onClick={() => setSortBy('views')}
                className={sortBy === 'views' ? 'bg-[#1E40AF]' : ''}
              >
                Most Viewed
              </Button>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="mb-4">
          <p className="text-gray-600">
            Showing {filteredDilemmas.length} {filteredDilemmas.length === 1 ? 'dilemma' : 'dilemmas'}
          </p>
        </div>

        {/* Dilemmas Grid */}
        {loading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[1, 2, 3, 4, 5, 6].map((i) => (
              <div key={i} className="h-48 bg-white rounded-lg animate-pulse" />
            ))}
          </div>
        ) : filteredDilemmas.length > 0 ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredDilemmas.map((dilemma) => (
              <DilemmaCard key={dilemma.id} dilemma={dilemma} />
            ))}
          </div>
        ) : (
          <div className="text-center py-16 bg-white rounded-lg border-2 border-dashed border-gray-300">
            <TrendingUp className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <p className="text-gray-600">No dilemmas found matching your criteria</p>
          </div>
        )}
      </div>
    </div>
  );
}
