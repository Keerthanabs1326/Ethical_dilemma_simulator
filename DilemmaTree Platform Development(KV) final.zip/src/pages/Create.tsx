import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles, ChevronRight, Loader2 } from 'lucide-react';
import { Button } from '../components/ui/button';
import { Input } from '../components/ui/input';
import { Textarea } from '../components/ui/textarea';
import { Label } from '../components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import { Card } from '../components/ui/card';
import { dilemmasApi } from '../utils/api';
import { toast } from 'sonner';

export function Create() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [loading, setLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'general',
  });

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = async () => {
    if (!formData.title || !formData.description) {
      toast.error('Please fill in all required fields');
      return;
    }

    setLoading(true);

    try {
      // Create dilemma
      const { data: createData, error: createError } = await dilemmasApi.create(
        formData.title,
        formData.description,
        formData.category
      );

      if (createError || !createData) {
        toast.error(createError || 'Failed to create dilemma');
        setLoading(false);
        return;
      }

      const dilemmaId = createData.dilemma.id;

      // Generate AI tree
      toast.info('Generating outcome tree with AI...');
      
      const { data: treeData, error: treeError } = await dilemmasApi.generateTree(
        dilemmaId,
        createData.dilemma
      );

      if (treeError) {
        console.error('Tree generation error:', treeError);
        toast.error('Failed to generate outcome tree: ' + treeError);
        setLoading(false);
        return;
      }

      console.log('Tree generated successfully:', treeData);
      toast.success('Dilemma created successfully!');
      navigate(`/dilemma/${dilemmaId}`);
    } catch (error) {
      console.error('Create error:', error);
      toast.error('Failed to create dilemma');
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-4xl">
        {/* Header */}
        <div className="mb-8 text-center">
          <div className="inline-flex items-center gap-2 bg-[#1E40AF]/10 px-4 py-2 rounded-full mb-4">
            <Sparkles className="h-4 w-4 text-[#1E40AF]" />
            <span className="text-sm text-[#1E40AF]">AI-Powered Analysis</span>
          </div>
          <h1 className="mb-2">Create a New Dilemma</h1>
          <p className="text-gray-600">
            Describe your dilemma and let AI generate a comprehensive outcome tree
          </p>
        </div>

        {/* Progress Steps */}
        <div className="flex items-center justify-center gap-4 mb-8">
          <div className={`flex items-center gap-2 ${step >= 1 ? 'text-[#1E40AF]' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 1 ? 'bg-[#1E40AF] text-white' : 'bg-gray-200'}`}>
              1
            </div>
            <span className="text-sm">Details</span>
          </div>
          <ChevronRight className="h-4 w-4 text-gray-400" />
          <div className={`flex items-center gap-2 ${step >= 2 ? 'text-[#1E40AF]' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 2 ? 'bg-[#1E40AF] text-white' : 'bg-gray-200'}`}>
              2
            </div>
            <span className="text-sm">Review</span>
          </div>
          <ChevronRight className="h-4 w-4 text-gray-400" />
          <div className={`flex items-center gap-2 ${step >= 3 ? 'text-[#1E40AF]' : 'text-gray-400'}`}>
            <div className={`w-8 h-8 rounded-full flex items-center justify-center ${step >= 3 ? 'bg-[#1E40AF] text-white' : 'bg-gray-200'}`}>
              3
            </div>
            <span className="text-sm">Generate</span>
          </div>
        </div>

        {/* Step 1: Details */}
        {step === 1 && (
          <Card className="p-8">
            <div className="space-y-6">
              <div>
                <Label htmlFor="title">Dilemma Title *</Label>
                <Input
                  id="title"
                  placeholder="e.g., Should we prioritize profit over environmental impact?"
                  value={formData.title}
                  onChange={(e) => handleInputChange('title', e.target.value)}
                  className="mt-2"
                />
              </div>

              <div>
                <Label htmlFor="description">Detailed Description *</Label>
                <Textarea
                  id="description"
                  placeholder="Provide context, stakeholders, constraints, and any relevant background information..."
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  className="mt-2 min-h-[200px]"
                />
                <p className="text-sm text-gray-500 mt-2">
                  The more detail you provide, the better the AI can analyze your dilemma
                </p>
              </div>

              <div>
                <Label htmlFor="category">Category</Label>
                <Select
                  value={formData.category}
                  onValueChange={(value) => handleInputChange('category', value)}
                >
                  <SelectTrigger className="mt-2">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="ethical">Ethical</SelectItem>
                    <SelectItem value="strategic">Strategic</SelectItem>
                    <SelectItem value="personal">Personal</SelectItem>
                    <SelectItem value="business">Business</SelectItem>
                    <SelectItem value="general">General</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="flex justify-end">
                <Button
                  onClick={() => setStep(2)}
                  disabled={!formData.title || !formData.description}
                  className="bg-[#1E40AF] hover:bg-[#1E40AF]/90"
                >
                  Continue to Review
                  <ChevronRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Step 2: Review */}
        {step === 2 && (
          <Card className="p-8">
            <div className="space-y-6">
              <div>
                <h3 className="mb-2">Review Your Dilemma</h3>
                <p className="text-gray-600">
                  Make sure everything looks correct before generating the outcome tree
                </p>
              </div>

              <div className="space-y-4 p-4 bg-gray-50 rounded-lg">
                <div>
                  <div className="text-sm text-gray-500 mb-1">Title</div>
                  <div>{formData.title}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500 mb-1">Description</div>
                  <div className="text-gray-700">{formData.description}</div>
                </div>
                <div>
                  <div className="text-sm text-gray-500 mb-1">Category</div>
                  <div className="inline-block px-3 py-1 bg-[#1E40AF]/10 text-[#1E40AF] rounded-full text-sm">
                    {formData.category}
                  </div>
                </div>
              </div>

              <div className="flex justify-between">
                <Button
                  variant="outline"
                  onClick={() => setStep(1)}
                  disabled={loading}
                >
                  Back
                </Button>
                <Button
                  onClick={handleSubmit}
                  disabled={loading}
                  className="bg-[#10B981] hover:bg-[#10B981]/90 gap-2"
                >
                  {loading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Generating with AI...
                    </>
                  ) : (
                    <>
                      <Sparkles className="h-4 w-4" />
                      Generate Outcome Tree
                    </>
                  )}
                </Button>
              </div>
            </div>
          </Card>
        )}

        {/* Info Box */}
        <div className="mt-8 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-900">
            💡 <strong>Tip:</strong> Our AI will analyze your dilemma and generate a comprehensive tree
            showing multiple decision paths, their probabilities, and potential impacts. You can then
            explore, vote on, and discuss these outcomes with the community.
          </p>
        </div>
      </div>
    </div>
  );
}
