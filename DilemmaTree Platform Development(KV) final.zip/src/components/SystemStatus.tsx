import { useState, useEffect } from 'react';
import { CheckCircle, XCircle, Loader2, AlertCircle } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { createClient } from '../utils/supabase-client';
import { dilemmasApi } from '../utils/api';

interface StatusCheck {
  name: string;
  status: 'checking' | 'success' | 'error' | 'warning';
  message: string;
}

export function SystemStatus() {
  const [checks, setChecks] = useState<StatusCheck[]>([
    { name: 'Supabase Connection', status: 'checking', message: 'Checking...' },
    { name: 'API Endpoints', status: 'checking', message: 'Checking...' },
    { name: 'Authentication', status: 'checking', message: 'Checking...' },
  ]);
  const [isChecking, setIsChecking] = useState(false);

  const runChecks = async () => {
    setIsChecking(true);
    const newChecks: StatusCheck[] = [];

    // Check 1: Supabase Connection
    try {
      const supabase = createClient();
      if (supabase) {
        newChecks.push({
          name: 'Supabase Connection',
          status: 'success',
          message: 'Connected to Supabase successfully',
        });
      }
    } catch (error) {
      newChecks.push({
        name: 'Supabase Connection',
        status: 'error',
        message: `Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}`,
      });
    }

    // Check 2: API Endpoints
    try {
      const { data, error } = await dilemmasApi.getAll();
      if (data || error === 'Network error. Please check your internet connection and try again.') {
        newChecks.push({
          name: 'API Endpoints',
          status: error ? 'warning' : 'success',
          message: error ? 'API reachable but returned an error' : 'API endpoints working correctly',
        });
      }
    } catch (error) {
      newChecks.push({
        name: 'API Endpoints',
        status: 'error',
        message: 'Failed to reach API endpoints',
      });
    }

    // Check 3: Authentication Status
    try {
      const supabase = createClient();
      const { data } = await supabase.auth.getSession();
      
      if (data.session) {
        newChecks.push({
          name: 'Authentication',
          status: 'success',
          message: 'Logged in successfully',
        });
      } else {
        newChecks.push({
          name: 'Authentication',
          status: 'warning',
          message: 'Not logged in (this is normal if you haven\'t signed in yet)',
        });
      }
    } catch (error) {
      newChecks.push({
        name: 'Authentication',
        status: 'error',
        message: 'Auth check failed',
      });
    }

    setChecks(newChecks);
    setIsChecking(false);
  };

  useEffect(() => {
    runChecks();
  }, []);

  const getStatusIcon = (status: StatusCheck['status']) => {
    switch (status) {
      case 'checking':
        return <Loader2 className="h-5 w-5 text-gray-400 animate-spin" />;
      case 'success':
        return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'warning':
        return <AlertCircle className="h-5 w-5 text-yellow-600" />;
      case 'error':
        return <XCircle className="h-5 w-5 text-red-600" />;
    }
  };

  const allChecksPass = checks.every(check => 
    check.status === 'success' || check.status === 'warning'
  );

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="font-semibold">System Status</h3>
        <Button
          onClick={runChecks}
          disabled={isChecking}
          variant="outline"
          size="sm"
        >
          {isChecking ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Checking...
            </>
          ) : (
            'Recheck'
          )}
        </Button>
      </div>

      <div className="space-y-3">
        {checks.map((check, index) => (
          <div key={index} className="flex items-start gap-3">
            <div className="mt-0.5">{getStatusIcon(check.status)}</div>
            <div className="flex-1">
              <p className="font-medium text-sm">{check.name}</p>
              <p className="text-xs text-gray-600">{check.message}</p>
            </div>
          </div>
        ))}
      </div>

      {!isChecking && (
        <div className={`mt-4 p-3 rounded-lg ${
          allChecksPass 
            ? 'bg-green-50 border border-green-200' 
            : 'bg-red-50 border border-red-200'
        }`}>
          <p className={`text-sm font-medium ${
            allChecksPass ? 'text-green-800' : 'text-red-800'
          }`}>
            {allChecksPass 
              ? '✅ All systems operational' 
              : '⚠️ Some systems need attention'}
          </p>
          {!allChecksPass && (
            <p className="text-xs text-gray-600 mt-1">
              Check the troubleshooting guide for help resolving issues.
            </p>
          )}
        </div>
      )}
    </Card>
  );
}
