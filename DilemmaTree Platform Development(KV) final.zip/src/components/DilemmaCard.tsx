import { Link } from 'react-router-dom';
import { Eye, ThumbsUp, ThumbsDown, MessageCircle, GitBranch } from 'lucide-react';
import { Card } from './ui/card';

interface DilemmaCardProps {
  dilemma: {
    id: string;
    title: string;
    description: string;
    category: string;
    views: number;
    votes_up: number;
    votes_down: number;
    created_at: string;
  };
}

export function DilemmaCard({ dilemma }: DilemmaCardProps) {
  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      ethical: 'bg-[#10B981]/10 text-[#10B981] border-[#10B981]/20',
      strategic: 'bg-[#1E40AF]/10 text-[#1E40AF] border-[#1E40AF]/20',
      personal: 'bg-[#F59E0B]/10 text-[#F59E0B] border-[#F59E0B]/20',
      business: 'bg-purple-100 text-purple-700 border-purple-200',
      general: 'bg-gray-100 text-gray-700 border-gray-200',
    };
    return colors[category] || colors.general;
  };

  return (
    <Link to={`/dilemma/${dilemma.id}`}>
      <Card className="p-6 hover:shadow-lg transition-shadow cursor-pointer border border-gray-200">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1">
              <h3 className="mb-2">{dilemma.title}</h3>
              <p className="text-gray-600 line-clamp-2">{dilemma.description}</p>
            </div>
            <div className={`px-3 py-1 rounded-full border text-xs whitespace-nowrap ${getCategoryColor(dilemma.category)}`}>
              {dilemma.category}
            </div>
          </div>

          {/* Stats */}
          <div className="flex items-center gap-6 text-sm text-gray-600">
            <div className="flex items-center gap-1">
              <Eye className="h-4 w-4" />
              <span>{dilemma.views || 0}</span>
            </div>
            <div className="flex items-center gap-1 text-[#10B981]">
              <ThumbsUp className="h-4 w-4" />
              <span>{dilemma.votes_up || 0}</span>
            </div>
            <div className="flex items-center gap-1 text-gray-400">
              <ThumbsDown className="h-4 w-4" />
              <span>{dilemma.votes_down || 0}</span>
            </div>
            <div className="flex items-center gap-1">
              <GitBranch className="h-4 w-4" />
              <span>Explore Tree</span>
            </div>
          </div>

          {/* Date */}
          <div className="text-xs text-gray-500">
            Created {new Date(dilemma.created_at).toLocaleDateString()}
          </div>
        </div>
      </Card>
    </Link>
  );
}
