import { useCallback, useEffect, useState } from 'react';
import ReactFlow, {
  MiniMap,
  Controls,
  Background,
  Node,
  Edge,
  Position,
  MarkerType,
} from 'reactflow';
import 'reactflow/dist/style.css';
import { Card } from './ui/card';
import { ThumbsUp, ThumbsDown } from 'lucide-react';

interface Branch {
  id: string;
  dilemma_id: string;
  parent_branch_id: string | null;
  content: string;
  outcome: string;
  probability: number;
  impact: number;
  depth: number;
  votes_up?: number;
  votes_down?: number;
}

interface OutcomeTreeFlowProps {
  branches: Branch[];
  onNodeClick?: (branch: Branch) => void;
  onVote?: (branchId: string, voteType: 'up' | 'down') => void;
}

const CustomNode = ({ data }: any) => {
  return (
    <Card className="p-4 min-w-[250px] max-w-[300px] border-2 border-gray-300 bg-white shadow-md">
      <div className="space-y-3">
        <div className="space-y-1">
          <div className="text-sm text-gray-500">Decision</div>
          <div className="font-medium text-gray-900">{data.content}</div>
        </div>
        
        {data.outcome && (
          <div className="space-y-1">
            <div className="text-sm text-gray-500">Outcome</div>
            <div className="text-sm text-gray-700">{data.outcome}</div>
          </div>
        )}
        
        <div className="flex items-center gap-4 text-xs">
          <div className="flex items-center gap-1">
            <span className="text-gray-500">Probability:</span>
            <span className="font-medium text-[#1E40AF]">{data.probability}%</span>
          </div>
          <div className="flex items-center gap-1">
            <span className="text-gray-500">Impact:</span>
            <span className="font-medium text-[#F59E0B]">{data.impact}/10</span>
          </div>
        </div>

        {data.showVotes && (
          <div className="flex items-center gap-3 pt-2 border-t">
            <button
              onClick={(e) => {
                e.stopPropagation();
                data.onVote?.(data.branchId, 'up');
              }}
              className="flex items-center gap-1 text-[#10B981] hover:opacity-70 transition-opacity"
            >
              <ThumbsUp className="h-4 w-4" />
              <span className="text-sm">{data.votes_up || 0}</span>
            </button>
            <button
              onClick={(e) => {
                e.stopPropagation();
                data.onVote?.(data.branchId, 'down');
              }}
              className="flex items-center gap-1 text-gray-400 hover:opacity-70 transition-opacity"
            >
              <ThumbsDown className="h-4 w-4" />
              <span className="text-sm">{data.votes_down || 0}</span>
            </button>
          </div>
        )}
      </div>
    </Card>
  );
};

const nodeTypes = {
  custom: CustomNode,
};

export function OutcomeTreeFlow({ branches, onNodeClick, onVote }: OutcomeTreeFlowProps) {
  const [nodes, setNodes] = useState<Node[]>([]);
  const [edges, setEdges] = useState<Edge[]>([]);

  useEffect(() => {
    if (!branches || branches.length === 0) return;

    // Create a layout for the tree
    const nodeMap = new Map<string, Branch>();
    branches.forEach(branch => nodeMap.set(branch.id, branch));

    // Calculate positions using depth-based layout
    const levelWidth = 400;
    const levelHeight = 200;
    const nodeCountByDepth = new Map<number, number>();

    branches.forEach(branch => {
      const count = nodeCountByDepth.get(branch.depth) || 0;
      nodeCountByDepth.set(branch.depth, count + 1);
    });

    const nodePositions = new Map<string, { x: number; y: number }>();
    const depthCounters = new Map<number, number>();

    branches
      .sort((a, b) => a.depth - b.depth)
      .forEach(branch => {
        const depth = branch.depth;
        const indexAtDepth = depthCounters.get(depth) || 0;
        depthCounters.set(depth, indexAtDepth + 1);

        const totalAtDepth = nodeCountByDepth.get(depth) || 1;
        const x = (indexAtDepth - (totalAtDepth - 1) / 2) * levelWidth;
        const y = depth * levelHeight;

        nodePositions.set(branch.id, { x, y });
      });

    // Create nodes
    const flowNodes: Node[] = branches.map(branch => {
      const position = nodePositions.get(branch.id) || { x: 0, y: 0 };
      
      return {
        id: branch.id,
        type: 'custom',
        position,
        data: {
          content: branch.content,
          outcome: branch.outcome,
          probability: branch.probability,
          impact: branch.impact,
          branchId: branch.id,
          votes_up: branch.votes_up,
          votes_down: branch.votes_down,
          showVotes: true,
          onVote,
        },
        sourcePosition: Position.Bottom,
        targetPosition: Position.Top,
      };
    });

    // Create edges
    const flowEdges: Edge[] = branches
      .filter(branch => branch.parent_branch_id)
      .map(branch => ({
        id: `e-${branch.parent_branch_id}-${branch.id}`,
        source: branch.parent_branch_id!,
        target: branch.id,
        type: 'smoothstep',
        animated: true,
        markerEnd: {
          type: MarkerType.ArrowClosed,
          color: '#1E40AF',
        },
        style: {
          stroke: '#1E40AF',
          strokeWidth: 2,
        },
      }));

    setNodes(flowNodes);
    setEdges(flowEdges);
  }, [branches, onVote]);

  const onNodeClickHandler = useCallback(
    (event: React.MouseEvent, node: Node) => {
      const branch = branches.find(b => b.id === node.id);
      if (branch && onNodeClick) {
        onNodeClick(branch);
      }
    },
    [branches, onNodeClick]
  );

  if (branches.length === 0) {
    return (
      <div className="flex items-center justify-center h-96 bg-gray-50 rounded-lg border-2 border-dashed border-gray-300">
        <div className="text-center text-gray-500">
          <p>No outcome tree generated yet.</p>
          <p className="text-sm mt-2">Create a dilemma and generate its outcome tree to visualize it here.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="h-[600px] bg-gray-50 rounded-lg border border-gray-200">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        nodeTypes={nodeTypes}
        onNodeClick={onNodeClickHandler}
        fitView
        minZoom={0.1}
        maxZoom={1.5}
        defaultViewport={{ x: 0, y: 0, zoom: 0.8 }}
      >
        <Background />
        <Controls />
        <MiniMap
          nodeColor={(node) => {
            return '#1E40AF';
          }}
          className="bg-white"
        />
      </ReactFlow>
    </div>
  );
}
