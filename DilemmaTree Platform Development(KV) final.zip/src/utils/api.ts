import { projectId, publicAnonKey } from './supabase/info';

const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-a0cbdfb4`;

export interface ApiResponse<T> {
  data?: T;
  error?: string;
}

async function apiCall<T>(
  endpoint: string,
  options: RequestInit = {},
  useAuth: boolean = false
): Promise<ApiResponse<T>> {
  try {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
      ...options.headers,
    };

    if (useAuth) {
      const token = localStorage.getItem('access_token');
      if (token) {
        headers['Authorization'] = `Bearer ${token}`;
      }
    } else {
      headers['Authorization'] = `Bearer ${publicAnonKey}`;
    }

    const response = await fetch(`${BASE_URL}${endpoint}`, {
      ...options,
      headers,
      mode: 'cors',
    });

    const data = await response.json();

    if (!response.ok) {
      console.error(`API error on ${endpoint}:`, data);
      return { error: data.error || 'Request failed' };
    }

    return { data };
  } catch (error) {
    console.error(`API call failed for ${endpoint}:`, error);
    
    // More helpful error messages
    if (error instanceof TypeError && error.message === 'Failed to fetch') {
      return { error: 'Network error. Please check your internet connection and try again.' };
    }
    
    return { error: error instanceof Error ? error.message : 'Network error' };
  }
}

// Auth API
export const authApi = {
  signup: (email: string, password: string, name: string) =>
    apiCall('/auth/signup', {
      method: 'POST',
      body: JSON.stringify({ email, password, name }),
    }),

  getMe: () => apiCall('/auth/me', {}, true),
};

// Dilemmas API
export const dilemmasApi = {
  create: (title: string, description: string, category: string) =>
    apiCall('/dilemmas', {
      method: 'POST',
      body: JSON.stringify({ title, description, category }),
    }, true),

  generateTree: (id: string, dilemma: any) =>
    apiCall(`/dilemmas/${id}/generate-tree`, {
      method: 'POST',
      body: JSON.stringify({ dilemma }),
    }, true),

  getAll: () => apiCall('/dilemmas'),

  getById: (id: string) => apiCall(`/dilemmas/${id}`),

  getBranches: (id: string) => apiCall(`/dilemmas/${id}/branches`),

  getComments: (id: string) => apiCall(`/dilemmas/${id}/comments`),

  getUserDilemmas: (userId: string) => apiCall(`/users/${userId}/dilemmas`),
};

// Voting API
export const votingApi = {
  vote: (dilemma_id: string, vote_type: 'up' | 'down', branch_id?: string) =>
    apiCall('/vote', {
      method: 'POST',
      body: JSON.stringify({ dilemma_id, branch_id, vote_type }),
    }, true),
};

// Comments API
export const commentsApi = {
  create: (dilemma_id: string, content: string, branch_id?: string) =>
    apiCall('/comments', {
      method: 'POST',
      body: JSON.stringify({ dilemma_id, content, branch_id }),
    }, true),
};

// Users API
export const usersApi = {
  getById: (userId: string) => apiCall(`/users/${userId}`),

  update: (userId: string, data: { name?: string; avatar?: string }) =>
    apiCall(`/users/${userId}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }, true),
};